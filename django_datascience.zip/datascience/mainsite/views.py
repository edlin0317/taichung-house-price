from django.http import HttpResponse
from datetime import datetime
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .scrapy import Twse
import time
# Create your views here.
# @login_required(login_url='register')
# def homescreen(request):
# 	# posts = Post.objects.all()
# 	#now = datetime.now()
# 	meta = FugleMeta(request.POST.get('fuglesid'))

# 	context4 = {"infos4":meta.fuglemeta()}
# 	# post_lists = list()
# 	# for count, post in enumerate(posts):
# 	# 	post_lists.append("No.{}:".format(str(count)) + str(post) +"<br>")
# 	# 	post_lists.append("<small>" + str(post.body.encode('utf-8').decode('utf-8'))+"</small><br><br>")
# 	return render(request, 'index.html', context4)
	# return HttpResponse(post_lists)


def tv(request,tvno = 0):
	tv_list = [{'name':'35線上賞屋','tvcode':'7MTi5q9fVIM'},
				{'name':'風傳媒','tvcode':'UUHVno5_oK4'},
				{'name':'好房網','tvcode':'TepDZndZw98'},]
	now = datetime.now()
	tvno = tvno
	tv = tv_list[tvno]
	return render(request,'boardbase.html',locals())


# def last_login(request):
# 	if request.user.is_authenticated:
# 		user = User.objects.get(username=request.user)
# 		last_login=user.last_login.strftime('%y-%m-%d')
# 		return HttpResponse(request, 'logintime.html', locals())
# 	else:
# 		return HttpResponse("<h1>Please log in</h1>")
# 	return HttpResponse("<h1>Page Not Found</h1>", status=404)



@login_required(login_url='register')
def index(request):
	#now = datetime.now()
#if 'sid' in request.POST:
	city = request.POST.get('city')
	district = request.POST.get('district')
	year = request.POST.get('year')
	lat = request.POST.get('lat')
	lon  = request.POST.get('lon')
	bs = request.POST.get('bs')
	g = request.POST.get('g')
	l  = request.POST.get('l')
	room = request.POST.get('room')
	living = request.POST.get('living')
	toilet = request.POST.get('toilet')
	s = request.POST.get('s')
	real_s = request.POST.get('real_s')


	twse = Twse(city, district,year,lat,lon,bs,g,l,room,living,toilet,s,real_s)

	context={"infos":twse.scrape()}
	return render(request, "index.html", context)

