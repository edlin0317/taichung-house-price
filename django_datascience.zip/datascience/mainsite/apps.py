from django.apps import AppConfig


class MainsiteConfig(AppConfig):
    name = 'mainsite'
