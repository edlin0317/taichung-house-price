import urllib.request as req
import requests
import json
import time,os
import datetime 
import bs4


class Website():
	def __init__(self, city, district, year, lat, lon, bs, g, l, room, living, toilet,  s, real_s):
		self.city = city
		self.district = district
		self.year = year
		self.lat= lat
		self.lon = lon
		self.bs = bs
		self.g = g
		self.l = l
		self.room = room
		self.living = living
		self.toilet = toilet
		self.s = s
		self.real_s = real_s

	def scrape(self):
		pass

class Twse(Website):
	

	def scrape(self):
		result=[]
		#self.date = date
		if self.city:
			url_twse = (f'https://taichunghouseprice.herokuapp.com/model_api?city={self.city}&district={self.district}&year={self.year}&lat={self.lat}&lon={self.lon}&bs={self.bs}&g={self.g}&l={self.l}&room={self.room}&living={self.living}&toilet={self.toilet}&s={self.s}&real_s={self.real_s}')
			print(url_twse)
			res =requests.post(url_twse,)
			soup = bs4.BeautifulSoup(res.text , 'html.parser')
			smt = json.loads(soup.text)
			print(smt)
			price = smt['p']
			totalprice = smt['tp']

			result.append(dict(price=price,totalprice=totalprice))
		return result
		print(result)